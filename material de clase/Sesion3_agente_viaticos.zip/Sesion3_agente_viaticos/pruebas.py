"""Batería de pruebas: corre cada caso de casos.csv contra el agente.

Uso:
    python pruebas.py

Lee casos.csv, le hace cada pregunta al agente en una conversación nueva
y escribe resultados.md con la respuesta y un veredicto automático.

Columnas de casos.csv:
    id, tipo, pregunta
    debe_incluir     -> fragmentos que la respuesta debe contener (separados por |)
    no_debe_incluir  -> fragmentos que la respuesta no puede contener (separados por |)

El veredicto automático es una ayuda, no un juez: lee siempre la respuesta.
"""

import csv
import time
import unicodedata
from datetime import datetime
from pathlib import Path

from agente import MODELO, responder

RAIZ = Path(__file__).parent
ARCHIVO_CASOS = RAIZ / "casos.csv"
ARCHIVO_RESULTADOS = RAIZ / "resultados.md"

PAUSA_SEGUNDOS = 6    # espera entre llamadas, para no superar el límite por minuto (RPM)
MAX_REINTENTOS = 3    # intentos extra cuando la API responde 429
ESPERA_429 = 30       # segundos de espera antes de reintentar tras un 429


def normalizar(texto):
    """Minúsculas y sin tildes, para comparar sin fallar por un acento."""
    sin_tildes = unicodedata.normalize("NFD", texto)
    sin_tildes = "".join(c for c in sin_tildes if unicodedata.category(c) != "Mn")
    return sin_tildes.lower()


def fragmentos(celda):
    return [f.strip() for f in (celda or "").split("|") if f.strip()]


def es_limite(error):
    """True si la API respondió 429: se alcanzó un límite del nivel gratuito."""
    codigo = getattr(error, "status_code", None) or getattr(error, "code", None)
    return codigo == 429 or "429" in str(error) or "RESOURCE_EXHAUSTED" in str(error)


def preguntar_con_reintentos(pregunta):
    """Llama al agente; si hay 429 espera y reintenta."""
    for intento in range(1, MAX_REINTENTOS + 2):
        try:
            respuesta, _ = responder(pregunta)  # sin id anterior: conversación nueva
            return respuesta
        except Exception as error:
            if es_limite(error) and intento <= MAX_REINTENTOS:
                espera = ESPERA_429 * intento
                print(f"   429: límite alcanzado. Espero {espera} s (intento {intento} de {MAX_REINTENTOS})...")
                time.sleep(espera)
                continue
            raise


def evaluar(respuesta, caso):
    """Devuelve (pasa, motivo) según las columnas debe_incluir y no_debe_incluir."""
    texto = normalizar(respuesta)
    for fragmento in fragmentos(caso.get("debe_incluir")):
        if normalizar(fragmento) not in texto:
            return False, f'falta: "{fragmento}"'
    for fragmento in fragmentos(caso.get("no_debe_incluir")):
        if normalizar(fragmento) in texto:
            return False, f'contiene: "{fragmento}"'
    return True, ""


def celda(texto):
    """Prepara un texto para una celda de tabla en Markdown."""
    return str(texto).replace("|", "\\|").replace("\r", "").replace("\n", "<br>")


def main():
    with open(ARCHIVO_CASOS, encoding="utf-8-sig", newline="") as archivo:
        casos = [c for c in csv.DictReader(archivo) if (c.get("pregunta") or "").strip()]

    filas = []
    aprobados = 0
    for numero, caso in enumerate(casos, start=1):
        print(f"[{numero}/{len(casos)}] {caso['tipo']}: {caso['pregunta'][:60]}")
        try:
            respuesta = preguntar_con_reintentos(caso["pregunta"])
            pasa, motivo = evaluar(respuesta, caso)
        except Exception as error:
            respuesta, pasa, motivo = f"ERROR: {error}", False, "la llamada falló"
        aprobados += pasa
        veredicto = "PASA" if pasa else f"FALLA ({motivo})"
        print(f"   {veredicto}")
        filas.append((caso["id"], caso["tipo"], caso["pregunta"], respuesta, veredicto))
        if numero < len(casos):
            time.sleep(PAUSA_SEGUNDOS)

    lineas = [
        "# Resultados de la batería de pruebas",
        "",
        f"- Fecha: {datetime.now():%Y-%m-%d %H:%M}",
        f"- Modelo: {MODELO}",
        f"- Resultado: pasaron {aprobados} de {len(casos)} casos",
        "",
        "| # | Tipo | Pregunta | Respuesta del agente | Veredicto |",
        "| --- | --- | --- | --- | --- |",
    ]
    lineas += ["| " + " | ".join(celda(valor) for valor in fila) + " |" for fila in filas]
    ARCHIVO_RESULTADOS.write_text("\n".join(lineas) + "\n", encoding="utf-8")

    print(f"\nPasaron {aprobados} de {len(casos)} casos. Detalle en {ARCHIVO_RESULTADOS.name}")


if __name__ == "__main__":
    main()
