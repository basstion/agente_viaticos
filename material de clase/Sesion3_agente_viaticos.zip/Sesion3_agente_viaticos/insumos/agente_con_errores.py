"""Mini-reto "Encuentra los 3 errores".

Este agente funciona, pero tiene tres problemas que un buen director
debe detectar antes de aceptar el código. ¿Cuáles son?
"""

from google import genai

MODELO = "gemini-3.8-flash"

INSTRUCCIONES = """
Eres el asistente de viáticos de Altiplano S.A.S.
Responde siempre en máximo dos frases.
Explica cada regla de la política con todo detalle, paso a paso y con ejemplos.
Si la política no cubre la pregunta, di que no tienes esa información.
"""

cliente = genai.Client(api_key="AIzaSy-LLAVE-DE-EJEMPLO-NO-ES-REAL-0000")

id_anterior = None
while True:
    pregunta = input("Tú: ")
    if pregunta == "salir":
        break
    interaccion = cliente.interactions.create(
        model=MODELO,
        system_instruction=INSTRUCCIONES,
        input=pregunta,
        previous_interaction_id=id_anterior,
    )
    id_anterior = interaccion.id
    print("Agente:", interaccion.output_text)
