# Política de viáticos — Altiplano S.A.S. (empresa ficticia)

1. Aplica solo a viajes de trabajo aprobados por el jefe inmediato antes de viajar.
2. Alimentación: hasta $90.000 COP por día en viajes nacionales.
3. Hospedaje: hasta $280.000 COP por noche en viajes nacionales, en hoteles de máximo 4 estrellas.
4. Transporte local (taxi, aplicaciones, bus): hasta $60.000 COP por día.
5. Tiquetes aéreos: solo clase económica y comprados por la agencia de la empresa. No se reembolsan tiquetes comprados por cuenta propia.
6. Todo gasto mayor a $30.000 COP requiere factura electrónica a nombre de la empresa.
7. La solicitud de reembolso se presenta máximo 10 días hábiles después de regresar del viaje.
8. No se reembolsan bebidas alcohólicas, propinas, minibar, multas ni gastos de acompañantes.
9. Los reembolsos aprobados se pagan en la nómina siguiente a la aprobación.
10. Los viajes internacionales no están cubiertos por esta política; se tramitan directamente con Gestión Humana.
