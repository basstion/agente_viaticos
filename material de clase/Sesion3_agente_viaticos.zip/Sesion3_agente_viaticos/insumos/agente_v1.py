"""Mi primer agente: responde una pregunta usando Gemini.

Uso:
    python agente.py
    python agente.py "¿Qué es una API?"
"""

import sys

from dotenv import load_dotenv
from google import genai

load_dotenv()  # lee la llave GEMINI_API_KEY desde el archivo .env

# 1. El modelo: el motor que genera las respuestas.
MODELO = "gemini-3.8-flash"

# 2. Las instrucciones de sistema: quién es el agente y cómo debe responder.
INSTRUCCIONES = "Eres un asistente amable. Respondes en español, en máximo tres frases."

# 3. La llamada: enviamos la pregunta y recibimos la respuesta.
cliente = genai.Client()
pregunta = " ".join(sys.argv[1:]) or "¿Qué es un agente de IA?"

interaccion = cliente.interactions.create(
    model=MODELO,
    system_instruction=INSTRUCCIONES,
    input=pregunta,
)
print(interaccion.output_text)
