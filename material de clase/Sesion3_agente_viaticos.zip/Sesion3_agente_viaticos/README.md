# Sesión 3 · Proyecto de referencia: agente de viáticos

Clave de respuestas del instructor para la sesión 3 de "Desarrollo de Aplicaciones con IA".
Los estudiantes construyen este mismo proyecto desde cero, dirigiendo a Claude Code.

## Cómo ejecutarlo

1. Crear el entorno e instalar dependencias:
   - macOS / Linux: `python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
   - Windows: `py -m venv .venv` y luego `.venv\Scripts\pip install -r requirements.txt`
2. Copiar `.env.example` como `.env` y pegar la llave de Google AI Studio.
3. Conversar con el agente: `python agente.py`
4. Correr la batería de pruebas: `python pruebas.py` (escribe `resultados.md`)

## Qué hay aquí

| Archivo | Para qué sirve |
| --- | --- |
| `agente.py` | Agente final: chat de varios turnos que lee `prompts/sistema.md` |
| `prompts/sistema.md` | Prompt de sistema de referencia, con cuatro secciones en XML |
| `pruebas.py` | Batería con pausas, reintentos ante el 429 y veredicto automático |
| `casos.csv` | Los cinco casos base |
| `insumos/agente_v1.py` | Resultado esperado del ejercicio 1 |
| `insumos/politica_viaticos.md` | Política de viáticos de la empresa ficticia |
| `insumos/sistema_defectuoso.md` | Prompt defectuoso del ejercicio 2 |
| `insumos/agente_con_errores.py` | Código del mini-reto |

## Antes de clase

- El código se probó con un cliente simulado, no contra la API real. Hay que correrlo una vez con una llave gratuita.
- Verificar en Google AI Studio que el modelo de `MODELO` tenga cuota gratuita y ajustar `PAUSA_SEGUNDOS` en `pruebas.py` según el límite por minuto.
- Nivel gratuito: Google puede usar los prompts y las respuestas para mejorar sus productos. Solo datos ficticios.
