"""Agente de viáticos: un chat de varios turnos en la terminal, con Gemini.

Uso:
    python agente.py

Las tres partes de un agente en código:
    1. MODELO         -> el motor que genera las respuestas.
    2. INSTRUCCIONES  -> el prompt de sistema (vive en prompts/sistema.md).
    3. El bucle       -> pregunta, respuesta, siguiente pregunta (función chat).
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from google import genai

load_dotenv()  # lee la llave GEMINI_API_KEY desde el archivo .env

# 1. El modelo. Verifica en Google AI Studio que esté en el nivel gratuito.
MODELO = "gemini-3.8-flash"

# 2. El prompt de sistema, en un archivo aparte para editarlo sin tocar el código.
RAIZ = Path(__file__).parent
INSTRUCCIONES = (RAIZ / "prompts" / "sistema.md").read_text(encoding="utf-8")

if not os.getenv("GEMINI_API_KEY"):
    sys.exit("No encontré GEMINI_API_KEY. Crea el archivo .env a partir de .env.example y pega tu llave.")

cliente = genai.Client()


def responder(pregunta, id_anterior=None):
    """Envía una pregunta al modelo y devuelve (respuesta, id de la interacción).

    id_anterior encadena la pregunta con el turno previo, para que el agente
    recuerde la conversación. Con None empieza una conversación nueva.
    """
    interaccion = cliente.interactions.create(
        model=MODELO,
        system_instruction=INSTRUCCIONES,
        input=pregunta,
        previous_interaction_id=id_anterior,
    )
    return interaccion.output_text, interaccion.id


def chat():
    """3. El bucle: conversa hasta que el usuario escriba 'salir'."""
    print("Asistente de viáticos. Escribe 'salir' para terminar.\n")
    id_anterior = None
    while True:
        pregunta = input("Tú: ").strip()
        if pregunta.lower() in ("salir", "exit", "quit"):
            break
        if not pregunta:
            continue
        try:
            respuesta, id_anterior = responder(pregunta, id_anterior)
        except Exception as error:
            # Si el error es 429, se alcanzó el límite del nivel gratuito: espera un minuto.
            print(f"\n[No pude responder: {error}]\n")
            continue
        print(f"\nAgente: {respuesta}\n")


if __name__ == "__main__":
    chat()
