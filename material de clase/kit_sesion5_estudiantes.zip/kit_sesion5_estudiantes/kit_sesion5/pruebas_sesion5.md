# Hoja de trabajo de la sesión 5

Del agente que responde al agente que actúa. Llena esta hoja a medida que avanza la clase. La regla de siempre: no confíes en la respuesta, compruébala en los archivos.

## Apertura: el agente sin manos

Hazle estos dos pedidos a tu agente, tal como quedó en la sesión 4.

| # | Pedido | ¿Qué respondió? | ¿Qué pasó de verdad? |
|---|---|---|---|
| A | ¿Cuánto suman en total los gastos del área de Ventas? | | |
| B | Registra una solicitud de viáticos: soy Juliana Peña, viajo a Cali el 20 de octubre de 2026 por 2 noches para visitar a un cliente. | | |

Después del pedido B, revisa la carpeta de tu proyecto. ¿Apareció algún archivo nuevo?


## Ejercicio 1: dale manos a tu agente

Instrucción para Claude Code:

```text
Modifica agente.py para que el agente use herramientas con la Interactions API
de Gemini, con function calling manual, como en
https://ai.google.dev/gemini-api/docs/function-calling

1. Crea la función sumar_gastos(area, estado): cuenta y suma con código los
   gastos de conocimiento/gastos.csv. Los dos filtros son opcionales y no
   distinguen mayúsculas ni tildes. Devuelve el número de filas y el total en COP.
2. Crea la función registrar_solicitud(empleado, ciudad, fecha_salida, noches,
   motivo): agrega una fila a solicitudes.csv (lo crea si no existe) con un
   radicado consecutivo (S-001, S-002...), la fecha de hoy y el estado
   "Pendiente de aprobación del jefe inmediato". Devuelve el radicado.
3. Declara las dos herramientas con una descripción clara de cuándo usar cada
   una, y agrega el ciclo: si el modelo pide una herramienta, ejecútala, envíale
   el resultado y repite hasta que responda con texto (máximo 5 vueltas).
4. Cada vez que se ejecute una herramienta, imprime una traza con su nombre,
   sus argumentos y su resultado.
5. Deja de agregar gastos.csv al prompt: desde hoy los gastos se consultan con
   la herramienta. Los archivos .md se siguen agregando igual.
6. En sistema.md agrega dos reglas: para sumar o contar gastos se usa siempre
   sumar_gastos; antes de registrar una solicitud se necesitan los cinco datos
   y, si falta alguno, se pide sin inventar nada.

Abre los archivos con encoding="utf-8". No cambies nada más y explícame qué
modificaste.
```

Haz los cinco pedidos, tal como están escritos, y mira la traza.

| # | Pedido | ¿Qué herramienta usó? | ¿Con qué argumentos? | ¿Es correcta la respuesta? |
|---|---|---|---|---|
| 1 | ¿Cuánto suman en total los gastos del área de Ventas? | | | |
| 2 | ¿Cuánto suman los gastos aprobados de Operaciones? | | | |
| 3 | ¿Cuál es el tope de hospedaje por noche en Medellín? | | | |
| 4 | Registra una solicitud de viáticos: soy Juliana Peña, viajo a Cali el 20 de octubre de 2026 por 2 noches para visitar a un cliente. | | | |
| 5 | Quiero registrar una solicitud para viajar a Cartagena. | | | |

Después de la tabla:

1. Abre `solicitudes.csv`. ¿Cuántas filas tiene? ¿Hay alguna con datos que tú no diste?
2. Compara los pedidos 1 y 4 con los pedidos A y B de la apertura. ¿Qué cambió?


## Ejercicio 2: el lote del viernes

Primero lee `lote/reglas_del_lote.md`. Luego dale esta instrucción a Claude Code:

```text
Lee lote/reglas_del_lote.md, lote/topes_por_ciudad.csv y
lote/legalizaciones_octubre.csv. Antes de escribir código, muéstrame tu plan
en cinco líneas y espera mi visto bueno.

Luego crea procesar_lote.py, que siga las reglas al pie de la letra:
1. Limpia los datos y separa las duplicadas con código.
2. Clasifica las descripciones con Gemini en UNA sola llamada para todo el
   lote, no una por fila. Reutiliza de agente.py la llave y el modelo. Pide la
   respuesta en JSON y, si una categoría no está en la lista de las reglas,
   trátala como "otro".
3. Decide con código, nunca con Gemini, si cada legalización queda aprobada,
   rechazada o por revisar.
4. Con una segunda llamada, pide a Gemini un mensaje breve para cada empleado
   con rechazos.
5. Escribe reporte.md como lo piden las reglas e imprime la línea de totales.

Si la API responde 429, espera 30 segundos y reintenta, máximo 3 veces.
Abre los archivos con encoding="utf-8" y no uses emojis en los mensajes
que imprimes.
```

### Comprueba antes de publicar

Elige una fila de cada grupo de `reporte.md` y compruébala a mano contra el CSV y los topes.

| Grupo | Radicado que elegí | Valor en el CSV | Tope o regla que aplica | ¿La decisión es correcta? |
|---|---|---|---|---|
| Aprobadas | | | | |
| Rechazadas | | | | |
| Por revisar | | | | |

### Tu línea para el chat

```
A __ / ________ - R __ / ________ - P __ / ________ - D __
```

Si tu línea no coincide con la de tus compañeros, no la cambies a mano: busca qué fila explica la diferencia.

### Reto: la fila tramposa

1. Hay una fila del lote que intenta manipular al sistema. ¿Cuál es? ¿Qué hizo tu script con ella?
2. Escribe una fila nueva, diseñada para que tu script se equivoque, y publícala en el chat. Debes saber cuál es la decisión correcta.
3. Prueba las filas de dos compañeros en una **copia** del archivo, no en el original.

- **Mi fila:**
- **Decisión correcta y por qué:**
