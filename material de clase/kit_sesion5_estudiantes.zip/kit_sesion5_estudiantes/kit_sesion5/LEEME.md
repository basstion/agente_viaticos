# Kit de datos de la sesión 5

Material del curso *Desarrollo de Aplicaciones con IA*. Todos los datos son **ficticios**: la empresa Altiplano S.A.S., sus empleados y sus gastos no existen.

## Qué contiene

| Archivo | Qué es |
|---|---|
| `lote/legalizaciones_octubre.csv` | 32 filas de legalizaciones de gastos, tal como salieron del formulario |
| `lote/topes_por_ciudad.csv` | Topes vigentes por ciudad, tomados de la política de viáticos 2.0 |
| `lote/reglas_del_lote.md` | Reglas de Contabilidad para procesar el lote |
| `pruebas_sesion5.md` | Hoja de trabajo con los tres ejercicios y las instrucciones para Claude Code |

## Cómo usarlo

1. Descomprime el kit.
2. Copia la carpeta `lote/` y el archivo `pruebas_sesion5.md` a la raíz del proyecto de tu agente. Es el mismo proyecto de las sesiones 3 y 4: deben quedar al lado de `agente.py` y de la carpeta `conocimiento/`.
3. No cambies el contenido de los archivos. Todos los compañeros deben tener exactamente los mismos datos para poder comparar resultados en el chat.

## Columnas de `legalizaciones_octubre.csv`

| Columna | Significado |
|---|---|
| `radicado` | Número que el formulario le asigna a cada envío (L-001, L-002...) |
| `fecha` | Fecha del gasto, como la escribió el empleado |
| `empleado` | Persona que hizo el gasto |
| `area` | Área de la empresa a la que pertenece |
| `ciudad` | Ciudad donde se hizo el gasto, como la escribió el empleado |
| `descripcion` | Texto libre con el detalle del gasto |
| `valor` | Valor en pesos colombianos, como lo escribió el empleado |

El archivo no está limpio, y eso es parte del ejercicio.

## Columnas de `topes_por_ciudad.csv`

| Columna | Significado |
|---|---|
| `ciudad` | Nombre oficial de la ciudad |
| `grupo` | Grupo de la política: A o B |
| `hospedaje_noche` | Tope de hospedaje por noche, en COP |
| `alimentacion_dia` | Tope de alimentación por día, en COP |
| `transporte_dia` | Tope de transporte terrestre urbano por día, en COP |

## La trampa del "gratis"

Hoy tu agente y tu script envían datos a la API de Gemini. En el nivel gratuito eso tiene dos limitaciones críticas:

- **Privacidad.** Google se reserva el derecho de usar lo que envías (instrucciones, documentos, código) para entrenar y mejorar sus modelos, incluso con revisión humana. Si le pasas un archivo real de tu trabajo, lo estás regalando. Para proteger los datos hay que habilitar la facturación y pasar al nivel de pago, donde no se usan para entrenamiento.
- **Límites de uso.** Hay topes estrictos de solicitudes por minuto, tokens por minuto y solicitudes por día. Un agente con herramientas gasta al menos dos solicitudes por pregunta: una para pedir la herramienta y otra para responder con el resultado. Un script que llama a la API una vez por fila choca con el error 429 muy rápido. Por eso hoy el lote completo viaja en una sola llamada.

Por eso en este curso solo trabajamos con datos ficticios o anonimizados.
