# Prueba de fuego del agente

Haz las seis preguntas a tu agente, **tal como están escritas**, y registra lo que pasa. No confíes en la respuesta: abre los archivos de `conocimiento/` y comprueba tú mismo si es correcta.

| # | Pregunta | Respuesta del agente (resumen) | ¿Citó el archivo? | ¿Es correcta? | Observaciones |
|---|---|---|---|---|---|
| 1 | ¿Cuál es el tope de hospedaje por noche en Medellín? | | | | |
| 2 | Perdí la factura de un taxi de 45.000 pesos. ¿Qué puedo hacer? | | | | |
| 3 | ¿Cuál es el tope diario de alimentación para un viaje de trabajo a Miami? | | | | |
| 4 | ¿Cómo se llama el director del área de Ventas? | | | | |
| 5 | ¿Cuántos días tengo para legalizar mis gastos después de un viaje? | | | | |
| 6 | ¿Cuánto suman en total los gastos del área de Ventas? | | | | |

## Después de la tabla

1. ¿En cuáles preguntas falló tu agente? Anota el número y qué hizo mal (inventó, se contradijo, calculó mal, no citó).
2. Repite la pregunta 6 tres veces. ¿Te dio el mismo número las tres veces?
3. Elige un fallo y corrígelo cambiando las instrucciones del agente. Anota qué cambiaste y si funcionó.

## Tu pregunta trampa para el reto

Escribe aquí una pregunta diseñada para que el agente de un compañero se equivoque. Debes conocer la respuesta correcta y saber en qué archivo está (o saber que no está en ninguno).

- **Pregunta:**
- **Respuesta correcta:**
- **Dónde se comprueba:**
