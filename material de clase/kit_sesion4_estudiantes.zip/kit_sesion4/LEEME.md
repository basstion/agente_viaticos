# Kit de datos de la sesión 4

Material del curso *Desarrollo de Aplicaciones con IA*. Todos los datos son **ficticios**: la empresa Altiplano S.A.S., sus empleados y sus gastos no existen.

## Qué contiene

| Archivo | Qué es |
|---|---|
| `conocimiento/politica_viaticos.md` | Política de viáticos de la empresa |
| `conocimiento/preguntas_frecuentes.md` | Preguntas frecuentes de la mesa de ayuda |
| `conocimiento/gastos.csv` | 150 gastos de viaje legalizados entre julio y septiembre de 2026 |
| `pruebas.md` | Tabla para registrar la prueba de fuego de tu agente |

## Cómo usarlo

1. Descomprime el kit.
2. Copia la carpeta `conocimiento/` y el archivo `pruebas.md` a la raíz del proyecto de tu agente (el mismo proyecto de la sesión 3).
3. No cambies el contenido de los archivos. Todos los compañeros deben tener exactamente los mismos datos para que el reto del final funcione.

## Columnas de `gastos.csv`

| Columna | Significado |
|---|---|
| `id` | Identificador del gasto (G-001 a G-150) |
| `fecha` | Fecha del gasto, en formato AAAA-MM-DD |
| `empleado` | Persona que hizo el gasto |
| `area` | Área de la empresa a la que pertenece |
| `ciudad` | Ciudad de destino del viaje |
| `categoria` | Alimentación, Hospedaje, Transporte terrestre, Tiquetes aéreos u Otros |
| `descripcion` | Detalle del gasto |
| `valor_cop` | Valor en pesos colombianos, sin puntos ni comas |
| `estado` | Aprobado, Pendiente o Rechazado |

Cada fila es un gasto. En Alimentación y Transporte terrestre, la fila es el total de ese día. En Hospedaje, la fila es una noche.

## La trampa del "gratis"

Tu agente envía estos archivos a la API de Gemini en cada pregunta. En el nivel gratuito eso tiene dos limitaciones críticas:

- **Privacidad.** Google se reserva el derecho de usar lo que envías (instrucciones, documentos, código) para entrenar y mejorar sus modelos, incluso con revisión humana. Si le pasas documentos reales de tu trabajo, los estás regalando. Para proteger los datos hay que habilitar la facturación y pasar al nivel de pago, donde no se usan para entrenamiento.
- **Límites de uso.** Hay topes estrictos de solicitudes por minuto, tokens por minuto y solicitudes por día. Cada pregunta a tu agente envía los tres archivos completos, así que si preguntas muy rápido verás el error 429. Espera un minuto y vuelve a intentar.

Por eso en este curso solo trabajamos con datos ficticios o anonimizados.
